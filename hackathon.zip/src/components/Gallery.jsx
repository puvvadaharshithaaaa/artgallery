import React from 'react';
import './gallery.css';

export default function Gallery() {
  return (
    <div className='gallery'>
         <h1>Gallery</h1>
    </div>
  )
}
