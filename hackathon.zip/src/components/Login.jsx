import React, { useState } from "react";
import "./Login.css";
import { Link } from "react-router-dom";

const Login = () => {
  const [credentials, setCredentials] = useState({ email: "", password: "" });

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Login credentials:", credentials);
  };

  return (
    <div className="container">
      <div className="login-container">
        <div className="login-card">
          <h2>LOGIN</h2>
          <p>Login to make a purchase.</p>
          <form onSubmit={handleSubmit}>
            <input
              type="email"
              name="email"
              placeholder="Email"
              required
              onChange={handleChange}
            />
            <input
              type="password"
              name="password"
              placeholder="Password(min. 6 characters)"
              minLength="6"
              required
              onChange={handleChange}
            />
            <button type="submit">Login</button>
          </form>
          <p className="register-link">
            Don’t have an account yet? <Link to="/signup">Register</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
