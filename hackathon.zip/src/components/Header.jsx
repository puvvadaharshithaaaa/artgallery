import React, { useState } from 'react';
import { FaUserShield, FaUserPlus, FaSignInAlt, FaImages, FaBars } from 'react-icons/fa';
import './Header.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="header">
      <div className="logo">
        Jehangir Art Gallery
      </div>

      <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
        <FaBars />
      </button>

      <nav className={`nav ${menuOpen ? 'nav-open' : ''}`}>
        <a href="/admin" className="nav-item"><FaUserShield /> Admin</a>
        <a href="/signup" className="nav-item"><FaUserPlus /> Sign Up</a>
        <a href="/login" className="nav-item"><FaSignInAlt /> Login</a>
        <a href="/gallery" className="nav-item"><FaImages /> Gallery</a>
      </nav>
    </header>
  );
};

export default Header;
