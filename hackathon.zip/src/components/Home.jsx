import React from 'react';
import "./Home.css"

export default function Home() {
  return (
    <>
       <main>
            <div className='box'>
                <h1>Buy Original Art Online</h1>
                <p>Discover creative universe of our artists</p>
                <button>Expore Now</button>
            </div>
       </main>
    </>
  )
}
