import React, { useEffect, useState } from "react";
import "./dashboard.css";

const products = [
  { id: 1, artist: "SATYAJIT", price: 1100, img: "./paint1.png" },
  { id: 2, artist: "GIRISH P.", price: 900, img: "./paint2.png" },
  { id: 3, artist: "CHARLES", price: 1000, img: "./paint3.png" },
  { id: 4, artist: "NEEL MADHAV", price: 1500, img: "./paint4.png" },
];

const Dashboard = () => {
  const [cart, setCart] = useState([]);

  // Load cart from localStorage on component mount
  useEffect(() => {
    const storedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(storedCart);
  }, []);

  const handleAddToCart = (product) => {
    const updatedCart = [...cart, product];
    setCart(updatedCart);
    localStorage.setItem("cart", JSON.stringify(updatedCart));
    alert(`${product.artist}'s artwork added to cart!`);
  };

  return (
    <div className="home-container">
      <div className="intro">
        <h2>Welcome to Jahangir Art Gallery!</h2>
        <h4>
          <span className="highlight">PAINTINGS/SCULPTURES BY</span>
        </h4>
        <p>
          VIKAS DOGRA * VENU MADHAV * NEENA BIDIKAR * SANGH PAL * AMIT SINGH
        </p>
      </div>

      <h3 className="manage-heading">Manage Product</h3>

      <div className="gallery-box">
        {products.map((product) => (
          <div className="card" key={product.id}>
            <p><strong>Artist:</strong> {product.artist}</p>
            <p><strong>Price:</strong> ₹{product.price}</p>
            <img src={product.img} alt={product.artist} />
            <button className="add-btn" onClick={() => handleAddToCart(product)}>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
