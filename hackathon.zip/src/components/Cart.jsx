import React, { useEffect, useState } from "react";
import "./cart.css";

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    const storedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCartItems(storedCart);
  }, []);

  const handleRemove = (index) => {
    const updatedCart = [...cartItems];
    updatedCart.splice(index, 1);
    setCartItems(updatedCart);
    localStorage.setItem("cart", JSON.stringify(updatedCart));
  };

  const handlePrint = () => {
    window.print();
  };

  const handleConfirmOrder = () => {
    alert("Order confirmed!");
    localStorage.removeItem("cart");
    setCartItems([]);
  };

  const total = cartItems.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="cart-container">
      <table>
        <thead>
          <tr>
            <th>Item Number</th>
            <th>Artist</th>
            <th>Price</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {cartItems.map((item, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{item.artist}</td>
              <td>{item.price}</td>
              <td>
                <button className="remove-btn" onClick={() => handleRemove(index)}>
                  Remove
                </button>
              </td>
            </tr>
          ))}
          <tr>
            <td>
              <button className="print-btn" onClick={handlePrint}>
                🖨️ Print
              </button>
            </td>
            <td><strong>Total</strong></td>
            <td><strong>Rs {total}/-</strong></td>
            <td>
              <button className="confirm-btn" onClick={handleConfirmOrder}>
                Confirm Order
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Cart;
